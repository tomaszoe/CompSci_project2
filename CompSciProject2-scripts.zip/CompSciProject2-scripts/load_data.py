#%% Load and prepare the MNIST data
import torchvision
from torchvision import transforms 
import numpy as np
from skorch.helper import SliceDataset

def load_FashionMNIST():
    train_dataset = torchvision.datasets.FashionMNIST('classifier_data', train=True, download=True)
    test_dataset  = torchvision.datasets.FashionMNIST('classifier_data', train=False, download=True)

    transform = transforms.Compose([torchvision.transforms.ToTensor()])

    # Set the train transform
    train_dataset.transform = transform
    y_train = train_dataset.targets.numpy()  # Extract the target labels.

    # Set the test transform
    test_dataset.transform = transform
    y_test = test_dataset.targets.numpy()  # Extract the target labels.

    # Wraps a torch dataset to make it work with sklearn
    train_sliceable = SliceDataset(train_dataset)
    test_sliceable = SliceDataset(test_dataset)

    return train_sliceable, test_sliceable, y_train, y_test



def load_CIFAR():
    train_dataset = torchvision.datasets.CIFAR10('classifier_data', train=True, download=True)
    test_dataset  = torchvision.datasets.CIFAR10('classifier_data', train=False, download=True)

    transform = transforms.Compose([torchvision.transforms.ToTensor()])
    # Set the train transform
    train_dataset.transform = transform
    y_train = train_dataset.targets  # Extract the target labels
    y_train = np.asarray(y_train)    # Convert the target label list into an array
    
    # Set the test transform
    test_dataset.transform = transform
    y_test = test_dataset.targets    # Extract the target labels.
    y_test = np.asarray(y_test)      # Convert the target label list into an array

    # Wraps a torch dataset to make it work with sklearn
    train_sliceable = SliceDataset(train_dataset)
    test_sliceable = SliceDataset(test_dataset)
    
    return train_sliceable, test_sliceable, y_train, y_test

